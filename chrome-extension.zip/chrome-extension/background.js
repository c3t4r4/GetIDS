chrome.runtime.onInstalled.addListener(() => {
  console.log("GetIDS instalado!");
});
